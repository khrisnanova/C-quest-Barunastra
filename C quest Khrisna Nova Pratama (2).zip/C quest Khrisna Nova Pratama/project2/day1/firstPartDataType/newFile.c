#include <stdio.h> 

int main(){
    // int a = 1, b = 2; // deklarasi variabel
    // /*same as 
    // int a = 1;
    // int b = 2;*/

    // int calculate;
    // calculate = a + b ; //1 + 2

    // //printf ("hello world!")
    // printf("%d",calculate);

    // // printf("%d",calculate); 

    // int a = 1, b = 2;
    // a = a +1;
    // printf("%d",a);

    int a = 1;
    int a = 2;

}