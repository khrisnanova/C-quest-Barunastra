#include <stdio.h>
//1. Operator
//Operator adalah simbol yang digunakan untuk melakukan operasi pada variabel atau nilai. Dalam C, operator dibagi menjadi beberapa jenis:

//Jenis Operator:
//1.Matematika:
// (+)  (Penjumlahan)      int hasil = 5 + 3; // 8
// (-)  (Pengurangan)      int hasil = 5 - 3; // 2
// (*)  (Perkalian)        int hasil = 5 * 3; // 15
// (/)  (Pembagian)        int hasil = 10 / 2; // 5
// (%)  (Modulus)          int hasil = 10 % 3; // 1 (sisa bagi)

//2.Perbandingan: Menghasilkan nilai true atau false :
//== (Sama dengan)       if (a == b)
//!= (Tidak sama)        if (a != b)
//>  (Lebih besar)       if (a > b)
//<  (Lebih kecil)       if (a < b)
//>= (Lebih besar/sama)  if (a >= b)
//<= (Lebih kecil/sama)  if (a <= b)

//3.Logika: Digunakan untuk operasi logika.
//&& (AND)     if (a > 0 && b > 0)
//|| (OR)      if (a > 0 || b > 0)
//!  (NOT)     if (!(a > 0))

//4.Assignment : Memberikan nilai ke variabel.
// =  (Sama dengan)       a = 5;
// += (Tambah dengan)     a += 3; // Sama dengan a = a + 3;
// -= (Kurang dengan)     a -= 3;
// *= (Kali dengan)       a *= 3;
// /= (Bagi dengan)       a /= 3;

//2. Function
//Function adalah blok kode yang dapat digunakan kembali untuk melakukan tugas tertentu. Function mempermudah modularitas dan efisiensi program.
//return_type function_name(parameters) {
    // Body function
    //return value;}


// Function untuk menghitung penjumlahan
int tambah(int a, int b) {
    return a + b;
}

int main() {
    int hasil = tambah(5, 3); // Memanggil function
    printf("Hasil penjumlahan: %d\n", hasil);
    

//3. If-Else
//If-Else digunakan untuk percabangan logika, memungkinkan program menjalankan kode tertentu berdasarkan kondisi.
//Struktur If-Else:
//if (kondisi) {
    // Kode jika kondisi true
//} else {
    // Kode jika kondisi false}
  int angka = 7;

    if (angka > 0) {
        printf("Angka positif\n");
    } else {
        printf("Angka negatif atau nol\n");
    }
    


//4. Switch
//Switch digunakan untuk percabangan logika dengan banyak kondisi, lebih sederhana dibandingkan banyak if-else.
//Struktur Switch:
 int hari = 2;

    switch (hari) {
        case 1:
            printf("senin\n");
            break;
        case 2:
            printf("selasa\n");
            break;
        case 3:
            printf("rabu\n");
            break;
        default:
            printf("hari hari tidur\n");
    }
    return 0;
}

