// Array adalah sebuah struktur data yang digunakan untuk menyimpan sebuah elemen dengan tipe data yang sama dan indeks dimulai dari 0
// contoh array
#include <stdio.h>

int main()
{
    int nilai[] = {85, 90, 78, 92, 88}; // Menyimpan 5 nilai

    // Menampilkan nilai satu per satu
    printf("Nilai ke-1: %d\n", nilai[0]);
    printf("Nilai ke-2: %d\n", nilai[1]);
    printf("Nilai ke-3: %d\n", nilai[2]);
    printf("Nilai ke-4: %d\n", nilai[3]);
    printf("Nilai ke-5: %d\n", nilai[4]);

    // Char adalah tipe data yang digunakan untuk menyimpan karakter tunggal, seperti huruf, angka, atau simbol
    char nama[] = "Budi";

    // Menampilkan string
    printf("Nama: %s\n", nama);

    // Menampilkan karakter satu per satu
    printf("Huruf pertama: %c\n", nama[0]);
    printf("Huruf kedua: %c\n", nama[1]);
    printf("Huruf ketiga: %c\n", nama[2]);
    printf("Huruf keempat: %c\n", nama[3]);

    // contoh char yang disimpan dalam array
    char tim[20] = "Barunastra";

    // Menampilkan string
    printf("Nama lengkap: %s\n", tim);

    // Menampilkan karakter satu per satu menggunakan array
    printf("Huruf pertama: %c\n", tim[0]);
    printf("Huruf kedua: %c\n", tim[1]);
    printf("Huruf ketiga: %c\n", tim[2]);

    return 0;
}
